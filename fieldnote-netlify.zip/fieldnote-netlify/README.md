# Fieldnote — request & quote site (Netlify version)

## Deploying this zip

1. Extract this zip on your phone (most Files apps can do this — tap the
   zip, look for "Extract" or "Unzip").
2. Go to your GitHub repo → **Add file → Upload files**.
3. Navigate into each folder in GitHub first (tap into `app`, then `lib`,
   etc.) and use "Upload files" from inside that folder so the files land
   in the right place — or, if your phone's file picker lets you select an
   entire folder at once, GitHub will preserve the folder structure
   automatically.
4. Commit the upload.
5. In Netlify, trigger a new deploy (Deploys → Trigger deploy → Deploy site).

## Environment variables (set these in Netlify, not in GitHub)

- `DASHBOARD_PASSWORD` — your login password for `/dashboard`
- `SESSION_SECRET` — any long random string
- `SITE_URL` — your real Netlify URL once you have it (e.g.
  `https://fieldnote.netlify.app`)
- `STRIPE_SECRET_KEY`, `STRIPE_WEBHOOK_SECRET` — add once you're ready for
  payments
- `SMTP_HOST`, `SMTP_PORT`, `SMTP_USER`, `SMTP_PASS`, `FROM_EMAIL`,
  `NOTIFY_EMAIL` — add once you're ready for email notifications

## What's different from the plain version

Requests are stored using **Netlify Blobs** (`lib/db.js`) instead of a
local file, since Netlify's servers don't keep files between requests.
Netlify Blobs works automatically once deployed — no extra setup needed.
